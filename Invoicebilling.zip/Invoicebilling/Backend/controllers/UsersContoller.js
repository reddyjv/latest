const User = require('../models/Users');
 const bcrypt = require('bcryptjs'); // Make sure this is imported

exports.addUser= async (req, res) => {
    const { name, email, dob, role, password } = req.body;
    try {
        const newUser = new User({ name, email, dob, role, password });
        await newUser.save();
        res.status(201).send("User registered");
    } catch (err) {
        res.status(500).send("Error registering user");
    }
};

exports.LoginUser= async (req, res) => {
    const { email, password, role } = req.body;
    console.log("Received login request:", email, role);

    try {
        const user = await User.findOne({ email, role });
        if (!user) {
            console.log("User not found");
            return res.status(401).json({ success: false, message: 'Invalid email or role' });
        }
        const isMatch = await bcrypt.compare(password, user.password);
        if (!isMatch) {
            console.log("Password not match")
            return res.status(401).json({ success: false, message: 'Incorrect password' });
        }
        return res.json({ data:user,success: true, message: 'Login successful' });
    } catch (err) {
        console.error("Login error:", err);
        return res.status(500).json({ success: false, message: 'Server error', error: err.message });
    }   
};



