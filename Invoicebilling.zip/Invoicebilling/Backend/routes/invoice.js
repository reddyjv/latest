// routes/invoice.js
const express = require('express');
const router = express.Router();
const Invoice = require('../models/Invoices');

function generateInvoiceNumber(lastNumber) {
  if (!lastNumber) return 'INV1000';
  const num = parseInt(lastNumber.replace('INV', ''), 10) + 1;
  return `INV${num}`;
}

router.post('/createinvoice', async (req, res) => {
  try {
    const lastInvoice = await Invoice.findOne().sort({ _id: -1 });
    const newInvoiceNumber = generateInvoiceNumber(lastInvoice?.invoiceNumber);

    const now = new Date();
    const date = now.toLocaleDateString();
    const time = now.toLocaleTimeString();

    const invoice = new Invoice({
      invoiceNumber: newInvoiceNumber,
      date,
      time,
      customer: req.body.customer,
      items: req.body.items,
      totals: req.body.totals,
    });

    await invoice.save();
    res.status(201).json({ success: true, invoiceNumber: newInvoiceNumber, date, time });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

router.get('/all', async (req, res) => {
  try {
    const invoices = await Invoice.find().sort({ date: -1 });
    res.json(invoices);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Error fetching invoices' });
  }
});

router.get('/due', async (req, res) => {
  try {
    const creditBills = await Invoice.find({ "totals.paymentMode": "credit" });
    res.json(creditBills);
  } catch (error) {
    console.error('Error fetching credit bills:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});

module.exports = router;
