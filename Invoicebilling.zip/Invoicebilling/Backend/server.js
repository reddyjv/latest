const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json());

mongoose.connect('mongodb://localhost:27017/invoicebilling')

// app.use('/api/auth', require('./routes/auth'));
app.use('/api/products', require('./routes/products'));
app.use('/api/customers', require('./routes/customers'));
app.use('/api/invoices',require('./routes/invoice'));
app.use('/api/users',require('./routes/Users'))


app.listen(5000, () => console.log('Server running on port 5000'));
