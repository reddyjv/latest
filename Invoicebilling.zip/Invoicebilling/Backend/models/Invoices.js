// models/Invoice.js
const mongoose = require('mongoose');

const invoiceSchema = new mongoose.Schema({
  invoiceNumber: {
    type: String,
    required: true,
    unique: true,
  },
  date: String,
  time: String,
  customer: {
    customerId:String,
    cname: String,
    cphone: String,
    mailId: String,
    address: String,
  },
  items: [{
    pname: String,
    qty: Number,
    saleprice: String,
    discount: String,
    gst: String,
    total: String,
  }],
  totals: {
    totalPrice: Number,
    totalDiscount: Number,
    totalGST: Number,
    finalAmount: Number,
    specialDiscount:Number,
    paymentMode: String,
    cashReceived: String,
    changeToBeReturned: String
  }
});

module.exports = mongoose.model('Invoice', invoiceSchema);
