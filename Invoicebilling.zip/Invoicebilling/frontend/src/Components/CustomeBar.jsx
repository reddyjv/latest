import React, { useEffect } from 'react';
import AOS from 'aos';
import 'aos/dist/aos.css';
import '../App.css'

function App() {
    useEffect(() => {
        AOS.init({ duration: 1000 });
    }, []);

    return (
            <div className='background-container'>
            {/* NAVBAR */}
            <nav className="navbar navbar-expand-lg navbar-dark bg-primary shadow sticky-top">
                <div className="container-fluid">
                    <a className="navbar-brand fw-bold text-white" href="#">Automated <span style={{color:'maroon'}}>Billing System</span></a>
                    <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                        <span className="navbar-toggler-icon"></span>
                    </button>
                    <div className="collapse navbar-collapse" id="navbarNav">
                        <ul className="navbar-nav me-auto">
                            <li className="nav-item"><a className="nav-link text-white" href="#features">Features</a></li>
                            <li className="nav-item"><a className="nav-link text-white" href="#howitworks">How It Works</a></li>
                            <li className="nav-item"><a className="nav-link text-white" href="#contact">Contact</a></li>
                        </ul>
                        <div className="d-flex gap-2">
                            <button onClick={() => window.location.href = "/register"} className="btn btn-outline-light btn-sm">Sign Up</button>
                            <button onClick={() => window.location.href = "/login"}className="btn btn-light btn-sm">Login</button>
                        </div>
                    </div>
                </div>
            </nav>

            {/* HERO SECTION */}
            <header  className="bg-light text-center py-5" id="home">
                <div className="container">
                    <h1 className="display-4 fw-bold" data-aos="fade-down">Automated Invoice & Billing System</h1>
                    <p className="lead" data-aos="fade-up">Streamline your invoicing process with AI-powered automation.</p>
                    <a href="#features" className="btn btn-info mt-3">Explore Features</a>
                </div>
            </header>

            {/* FEATURES SECTION */}
            <section className="py-5 bg-white" id="features">
                <div className="container">
                    <h2 className="text-center mb-5" data-aos="fade-up">Key Features</h2>
                    <div className="row g-4">
                        <div className="col-md-4" data-aos="zoom-in">
                            <div className="card shadow h-100">
                                <div className="card-body">
                                    <h5 className="card-title text-info">Auto Invoice Generation</h5>
                                    <p className="card-text">Generate invoices from billing data with zero manual effort.</p>
                                </div>
                            </div>
                        </div>
                        <div className="col-md-4" data-aos="zoom-in" data-aos-delay="100">
                            <div className="card shadow h-100">
                                <div className="card-body">
                                    <h5 className="card-title text-info">Smart Analytics</h5>
                                    <p className="card-text">Track your earnings and client payments in one dashboard.</p>
                                </div>
                            </div>
                        </div>
                        <div className="col-md-4" data-aos="zoom-in" data-aos-delay="200">
                            <div className="card shadow h-100">
                                <div className="card-body">
                                    <h5 className="card-title text-info">Secure Data</h5>
                                    <p className="card-text">Your billing data is protected with enterprise-grade encryption.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            {/* HOW IT WORKS */}
            <section className="py-5 bg-light" id="howitworks">
                <div className="container">
                    <h2 className="text-center mb-5" data-aos="fade-up">How It Works</h2>
                    <div className="row text-center">
                        <div className="col-md-3" data-aos="fade-up">
                            <div className="p-3">
                                <span className="display-6 fw-bold text-info">1</span>
                                <p>Sign up and configure your billing preferences</p>
                            </div>
                        </div>
                        <div className="col-md-3" data-aos="fade-up" data-aos-delay="100">
                            <div className="p-3">
                                <span className="display-6 fw-bold text-info">2</span>
                                <p>Upload transaction data or connect your system</p>
                            </div>
                        </div>
                        <div className="col-md-3" data-aos="fade-up" data-aos-delay="200">
                            <div className="p-3">
                                <span className="display-6 fw-bold text-info">3</span>
                                <p>AI generates and sends invoices automatically</p>
                            </div>
                        </div>
                        <div className="col-md-3" data-aos="fade-up" data-aos-delay="300">
                            <div className="p-3">
                                <span className="display-6 fw-bold text-info">4</span>
                                <p>Track everything on your personalized dashboard</p>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            {/* CONTACT */}
            <section className="py-5 bg-white" id="contact">
                <div className="container">
                    <h2 className="text-center mb-4" data-aos="fade-up">Contact Us</h2>
                    <div className="text-center" data-aos="fade-up" data-aos-delay="100">
                        <p>Have questions? Reach out to our team anytime.</p>
                        <a href="mailto:support@dinvoice.com" className="btn btn-outline-info">support@dinvoice.com</a>
                    </div>
                </div>
            </section>

            {/* FOOTER */}
            <footer className="text-center py-3 bg-primary text-white">
                <div className="container">
                    &copy; 2025 Automate DInvoice. All rights reserved.
                </div>
            </footer>
            </div>
    );
}

export default App;
