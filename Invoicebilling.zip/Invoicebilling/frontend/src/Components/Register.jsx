import React, { useState } from 'react';
import axios from 'axios';
import bcrypt from 'bcryptjs';
import 'bootstrap/dist/css/bootstrap.min.css';

function Register() {
    const [formData, setFormData] = useState({
        name: '',
        email: '',
        dob: '',
        role: '',
        password: ''
    });

    const [errors, setErrors] = useState({});
    const [isFormValid, setIsFormValid] = useState(false);

    const handleChange = (e) => {
        const { name, value } = e.target;
        const updatedFormData = { ...formData, [name]: value };
        setFormData(updatedFormData);
        validateForm(updatedFormData);
    };

    const validateForm = (data) => {
        const newErrors = {};
        if (!data.name.trim()) newErrors.name = 'Name is required';
        if (!data.email.match(/^[\w.%+-]+@[\w.-]+\.[A-Za-z]{2,}$/)) newErrors.email = 'Enter a valid email';
        if (!data.dob) newErrors.dob = 'Date of birth is required';
        if (!data.role) newErrors.role = 'Please select a role';
        if (!data.password || data.password.length < 6)
            newErrors.password = 'Password must be at least 6 characters';

        setErrors(newErrors);
        setIsFormValid(Object.keys(newErrors).length === 0);
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        if (!isFormValid) return;

        try {
            const hashedPassword = await bcrypt.hash(formData.password, 10);
            const dataToSend = { ...formData, password: hashedPassword };

            await axios.post('http://localhost:5000/api/users/register', dataToSend);
            alert("User registered successfully!");

            // Reset form
            const resetForm = {
                name: '',
                email: '',
                dob: '',
                role: '',
                password: ''
            };
            setFormData(resetForm);
            setErrors({});
            setIsFormValid(false);

        } catch (error) {
            alert("Registration failed.");
            console.error(error);
        }
    };

    return (
        <div className="container d-flex justify-content-center align-items-center" style={{ minHeight: '100vh' }}>
            <form
                onSubmit={handleSubmit}
                className="p-4 border rounded bg-light shadow"
                style={{ width: '100%', maxWidth: '450px' }}
            >
                <h3 className="text-center mb-4">Register</h3>

                <div className="form-group mb-3">
                    <label>Name</label>
                    <input type="text" name="name" className="form-control" value={formData.name} onChange={handleChange} />
                    {errors.name && <small className="text-danger">{errors.name}</small>}
                </div>

                <div className="form-group mb-3">
                    <label>Email ID</label>
                    <input type="email" name="email" className="form-control" value={formData.email} onChange={handleChange} />
                    {errors.email && <small className="text-danger">{errors.email}</small>}
                </div>

                <div className="form-group mb-3">
                    <label>Date of Birth</label>
                    <input type="date" name="dob" className="form-control" value={formData.dob} onChange={handleChange} />
                    {errors.dob && <small className="text-danger">{errors.dob}</small>}
                </div>

                <div className="form-group mb-3">
                    <label>Role</label>
                    <div>
                        <div className="form-check form-check-inline">
                            <input className="form-check-input" type="radio" name="role" value="vendor" checked={formData.role === 'vendor'} onChange={handleChange} />
                            <label className="form-check-label">Vendor</label>
                        </div>
                        <div className="form-check form-check-inline">
                            <input className="form-check-input" type="radio" name="role" value="manager" checked={formData.role === 'manager'} onChange={handleChange} />
                            <label className="form-check-label">Manager</label>
                        </div>
                    </div>
                    {errors.role && <small className="text-danger d-block">{errors.role}</small>}
                </div>

                <div className="form-group mb-3">
                    <label>Password</label>
                    <input type="password" name="password" className="form-control" value={formData.password} onChange={handleChange} />
                    {errors.password && <small className="text-danger">{errors.password}</small>}
                </div>

                <button type="submit" className="btn btn-primary w-100" disabled={!isFormValid}>
                    Register
                </button>
            </form>
        </div>
    );
}

export default Register;
