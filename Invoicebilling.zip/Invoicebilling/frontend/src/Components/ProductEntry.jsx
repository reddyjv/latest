import React, { useEffect, useState } from 'react';
import BillingSummary from './BillingSummary';
import axios from 'axios';

const ProductEntry = ({ customer, onResetAll }) => {
  const [availableProducts, setAvailableProducts] = useState([]);
  const [entries, setEntries] = useState([createEmptyEntry()]);
  const [showSummary, setShowSummary] = useState(false);
  const [isDisabled, setIsDisabled] = useState(false);
  const customers = customer;

  function createEmptyEntry() {
    return {
      pname: '',
      qty: 1,
      saleprice: 0,
      GST: 0,
      discount: 0,
      batchNo: '',
      MRP: 0,
      category: ''
    };
  }

  useEffect(() => {
    const loadProducts = async () => {
      try {
        const response = await axios.get('http://localhost:5000/api/products');
        setAvailableProducts(response.data);
      } catch (error) {
        console.error('Error fetching products:', error);
      }
    };
    loadProducts();
  }, []);

  const handleChange = (index, key, value) => {
    const newEntries = [...entries];
    newEntries[index][key] = key === 'pname' ? value : parseFloat(value) || 0;
    setEntries(newEntries);
  };

  const handleSelect = (index, pname) => {
    const selected = availableProducts.find(p => p.pname === pname);
    if (selected) {
      const updated = {
        ...entries[index],
        pname: selected.pname,
        saleprice: selected.saleprice,
        GST: selected.GST,
        MRP: selected.MRP,
        batchNo: selected.batchNo,
        category: selected.category,
        discount: 0
      };
      const newEntries = [...entries];
      newEntries[index] = updated;
      setEntries(newEntries);
    }
  };

  const handleAddMore = () => {
    setEntries([...entries, createEmptyEntry()]);
  };

  const handleDeleteRow = (index) => {
    const newEntries = entries.filter((_, i) => i !== index);
    setEntries(newEntries);
  };

  const handleCalculateBill = () => {
    setShowSummary(true);
    setIsDisabled(true);
  };

  const handleReset = () => {
    setEntries([createEmptyEntry()]);
    setShowSummary(false);
    setIsDisabled(false);
    if (onResetAll) onResetAll();
  };

  return (
    <div className="container-fluid mt-5 p-4 rounded shadow-lg" style={{ background: '#f8f9fa' }}>
      <h4 className="mb-4 text-center" style={{ color: '#0d6efd',fontWeight: 'bold' }}>Product Billing Panel</h4>
      <div className="table-responsive">
        <table className="table table-bordered align-middle">
          <thead className="table-light text-center">
            <tr style={{ backgroundColor: '#343a40', color: 'white' }}>
              <th>Product</th>
              <th>Qty</th>
              <th>Sale Price</th>
              <th>MRP</th>
              <th>GST %</th>
              <th>Discount</th>
              <th>Batch No</th>
              <th>Category</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {entries.map((entry, index) => (
              <tr key={index}>
                <td>
                  <select
                    className="form-select"
                    value={entry.pname}
                    onChange={(e) => handleSelect(index, e.target.value)}
                    disabled={isDisabled}
                  >
                    <option value="">Select</option>
                    {availableProducts.map((p) => (
                      <option key={p.productId} value={p.pname}>
                        {p.pname}
                      </option>
                    ))}
                  </select>
                </td>
                <td>
                  <input
                    type="number"
                    className="form-control"
                    min="1"
                    value={entry.qty}
                    onChange={(e) => handleChange(index, 'qty', e.target.value)}
                    disabled={isDisabled}
                  />
                </td>
                <td>
                  <input
                    type="number"
                    className="form-control"
                    value={entry.saleprice}
                    disabled
                    style={{ backgroundColor: '#f1f1f1', borderColor: '#ddd' }}
                  />
                </td>
                <td>
                  <input
                    type="number"
                    className="form-control"
                    value={entry.MRP}
                    disabled
                    style={{ backgroundColor: '#f1f1f1', borderColor: '#ddd' }}
                  />
                </td>
                <td>
                  <input
                    type="number"
                    className="form-control"
                    value={entry.GST}
                    disabled
                    style={{ backgroundColor: '#f1f1f1', borderColor: '#ddd' }}
                  />
                </td>
                <td>
                  <input
                    type="number"
                    className="form-control"
                    value={entry.discount}
                    onChange={(e) => handleChange(index, 'discount', e.target.value)}
                    disabled={isDisabled}
                  />
                </td>
                <td>
                  <input
                    type="text"
                    className="form-control"
                    value={entry.batchNo}
                    disabled
                  />
                </td>
                <td>
                  <input
                    type="text"
                    className="form-control"
                    value={entry.category}
                    disabled
                  />
                </td>
                <td>
                  <button
                    type="button"
                    className="btn btn-danger"
                    onClick={() => handleDeleteRow(index)}
                    disabled={isDisabled}
                    style={{
                      backgroundColor: '#dc3545',
                      color: 'white',
                      borderRadius: '5%',
                      fontSize: '12px',
                      padding: '8px 12px',
                    }}
                  >
                    remove
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="mt-4 d-flex justify-content-between">
        <button
          className="btn btn-outline-primary"
          onClick={handleAddMore}
          disabled={isDisabled}
          style={{
            backgroundColor: '#007bff',
            color: 'white',
            borderRadius: '10px',
            padding: '10px 20px',
            fontWeight: 'bold'
          }}
        >
          Add More Product
        </button>
        <button
          className="btn btn-success"
          onClick={handleCalculateBill}
          disabled={isDisabled}
          style={{
            backgroundColor: '#28a745',
            color: 'white',
            borderRadius: '10px',
            padding: '10px 20px',
            fontWeight: 'bold'
          }}
        >
          Save & Calculate Bill
        </button>
      </div>

      {showSummary && <BillingSummary products={entries} customer={customers} onReset={handleReset} />}
    </div>
  );
};

export default ProductEntry;
