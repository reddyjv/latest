import { useEffect, useState } from 'react';
import axios from 'axios';
import * as XLSX from 'xlsx';
import './styles.css';
import { useNavigate } from 'react-router';

const CustomerList = () => {
  const [customers, setCustomers] = useState([]);
  const [searchInput, setSearchInput] = useState('');
  const [filteredCustomers, setFilteredCustomers] = useState([]);
  const navigate=useNavigate();

  const fetchCustomers = () => {
    axios.get('http://localhost:5000/api/customers')
      .then(res => {
        setCustomers(res.data);
        setFilteredCustomers(res.data);
      })
      .catch(err => console.error(err));
  };

  useEffect(() => {
    fetchCustomers();
  }, []);

  const handleSearch = () => {
    const filtered = customers.filter(cust =>
      cust.cphone.toString().includes(searchInput)
    );
    setFilteredCustomers(filtered);
  };

  const filtered = customers.filter(cust =>
    cust.cphone.toString().includes(searchInput)
  );

  const handleDelete = async (id) => {
    if (window.confirm('Are you sure you want to delete this customer?')) {
      try {
        await axios.delete(`http://localhost:5000/api/customers/delete/${id}`);
        fetchCustomers();
      } catch (error) {
        console.error('Delete failed:', error);
      }
    }
  };

  const handleUpdate = (customerId) => {
    navigate(`/updatecustomer/${customerId}`);
  };

  const downloadExcel = () => {
    const worksheet = XLSX.utils.json_to_sheet(filteredCustomers);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Customers');
    XLSX.writeFile(workbook, 'CustomerList.xlsx');
  };

  return (
    <div className="customer-table-wrapper container mt-4">
      <nav className="navbar navbar-expand-lg navbar-dark bg-success rounded mb-4 px-4">
        <span className="navbar-brand">👥 Customer Manager</span>
      </nav>

      <div className="d-flex flex-wrap justify-content-between align-items-center mb-4 gap-3">
        <div className="d-flex gap-2 flex-grow-1">
          <input
            type="text"
            className="form-control search-input"
            placeholder="Search by phone number"
            value={searchInput}
            onChange={(e) => setSearchInput(e.target.value)}
          />
          <button className="btn btn-outline-success" onClick={handleSearch}>
            Search
          </button>
        </div>

        <button className="btn btn-outline-primary" onClick={downloadExcel}>
          Download Excel
        </button>
      </div>

      <div className="table-responsive rounded shadow-sm">
        <table className="table table-bordered table-hover table-light text-center">
          <thead className="table-dark">
            <tr>
              <th>ID</th>
              <th>Name</th>
              <th>Phone</th>
              <th>Email</th>
              <th>Address</th>
              <th>Type</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            {filteredCustomers.length > 0 ? (
              filteredCustomers.map(cust => (
                <tr key={cust.customerId}>
                  <td>{cust.customerId}</td>
                  <td>{cust.cname}</td>
                  <td>{cust.cphone}</td>
                  <td>{cust.mailId}</td>
                  <td>{cust.address}</td>
                  <td>{cust.category}</td>
                  <td>
                    <button style={{borderRadius:'10px'}} className="btn btn-sm btn-warning me-2" onClick={() => handleUpdate(cust.customerId)}>
                      Update
                    </button>
                    <button style={{borderRadius:'10px'}}className="btn btn-sm btn-danger" onClick={() => handleDelete(cust.customerId)}>
                      Delete
                    </button>
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan="7" className="text-center">No customers found.</td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      <div className="mt-4 text-end">
        <h5 className="text-muted">
          <strong>Total Registered Customers:</strong> {filteredCustomers.length}
        </h5>
      </div>
    </div>
  );
};

export default CustomerList;
