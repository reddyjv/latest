import React, { useState } from 'react';
import { Navigate, useNavigate } from 'react-router-dom';
import axios from 'axios';
import 'bootstrap/dist/css/bootstrap.min.css';

function Login({ onLoginSuccess }) {
    const navigate = useNavigate();

    const [formData, setFormData] = useState({
        email: '',
        password: '',
        role: ''
    });

    const [errors, setErrors] = useState({});
    const [isFormValid, setIsFormValid] = useState(false);

    const handleChange = (e) => {
        const { name, value } = e.target;
        const updatedFormData = { ...formData, [name]: value };
        setFormData(updatedFormData);
        validateForm(updatedFormData);
    };

    const validateForm = (data) => {
        const newErrors = {};
        if (!data.email.match(/^[\w.%+-]+@[\w.-]+\.[A-Za-z]{2,}$/)) newErrors.email = 'Enter a valid email';
        if (!data.role) newErrors.role = 'Please select a role';

        setErrors(newErrors);
        setIsFormValid(Object.keys(newErrors).length === 0);
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        if (!isFormValid) return;

        try {
            const response = await axios.post('http://localhost:5000/api/users/login', formData);
            if (response.data.success) {
                alert("Login successful!");
                console.log("setting onloginsuccess",onLoginSuccess);
                <Navigate to='/dashboard1' user={response.data.data}/>
            } else {
                alert("Invalid credentials");
            }
        } catch (error) {
            if (error.response?.status === 401) {
                alert("Invalid email, password, or role");
            } else {
                alert("Server error. Please try again later.");
            }
        }
    };

    return (
        <div className="container d-flex justify-content-center align-items-center" style={{ minHeight: '100vh' }}>
            <form onSubmit={handleSubmit} className="p-4 border rounded bg-light shadow" style={{ width: '100%', maxWidth: '450px' }}>
                <h3 className="text-center mb-4">Login</h3>

                <div className="form-group mb-3">
                    <label>Email ID</label>
                    <input type="email" name="email" className="form-control" value={formData.email} onChange={handleChange} />
                    {errors.email && <small className="text-danger">{errors.email}</small>}
                </div>

                <div className="form-group mb-3">
                    <label>Password</label>
                    <input type="password" name="password" className="form-control" value={formData.password} onChange={handleChange} />
                </div>

                <div className="form-group mb-3">
                    <label>Role</label>
                    <div>
                        <div className="form-check form-check-inline">
                            <input className="form-check-input" type="radio" name="role" value="vendor" checked={formData.role === 'vendor'} onChange={handleChange} />
                            <label className="form-check-label">Vendor</label>
                        </div>
                        <div className="form-check form-check-inline">
                            <input className="form-check-input" type="radio" name="role" value="manager" checked={formData.role === 'manager'} onChange={handleChange} />
                            <label className="form-check-label">Manager</label>
                        </div>
                    </div>
                    {errors.role && <small className="text-danger d-block">{errors.role}</small>}
                </div>

                <button type="submit" className="btn btn-success w-100" disabled={!isFormValid}>
                    Login
                </button>

                <div className="text-center mt-3">
                    <small>
                        Don't have an account?{' '}
                        <span className="text-primary" style={{ cursor: 'pointer', textDecoration: 'underline' }} onClick={() => navigate('/register')}>
                            Sign Up
                        </span>
                    </small>
                </div>
            </form>
        </div>
    );
}

export default Login;
