import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';

function Navbar({ user, onLogout }) {
    const getInitials = (name) => {
        const first = name?.charAt(0)?.toUpperCase() || '';
        const second = name?.charAt(1)?.toUpperCase() || '';
        return first + second;
    };

    const initials = getInitials(user?.name);

    return (
        <nav className="navbar navbar-light bg-light px-4 py-2 shadow-sm">
            <div className="container-fluid d-flex justify-content-between align-items-center">
                <h4 className="m-0">Your App</h4>
                <div className="d-flex align-items-center">
                    <div
                        className="rounded-circle bg-primary text-white d-flex justify-content-center align-items-center"
                        style={{
                            width: '40px',
                            height: '40px',
                            fontWeight: 'bold',
                            fontSize: '1rem',
                            marginRight: '10px'
                        }}
                    >
                        {initials}
                    </div>
                    <div className="d-flex flex-column align-items-start">
                        <span>{user?.name}</span>
                        <button onClick={onLogout} className="btn btn-sm btn-outline-danger mt-1">
                            Logout
                        </button>
                    </div>
                </div>
            </div>
        </nav>
    );
}

export default Navbar;
