import { useEffect, useState } from 'react';
import axios from 'axios';
import { useParams, useNavigate } from 'react-router-dom';
import './styles.css';

const UpdateCustomer = () => {
  const { id } = useParams();
  const navigate = useNavigate();

  const [customerData, setCustomerData] = useState({
    customerId: '',
    cname: '',
    cphone: '',
    mailId: '',
    address: '',
    category: 'Wholesaler',
    walletBal: ''
  });
  customerData.customerId=id
  const [message, setMessage] = useState({ type: '', text: '' });

  const fetchCustomer = async () => {
    try {
      const res = await axios.get(`http://localhost:5000/api/customers/getcust/${id}`);
      setCustomerData({ ...res.data });
    } catch (err) {
      console.error('Error fetching customer:', err);
      setMessage({ type: 'error', text: 'Failed to fetch customer data.' });
    }
  };

  useEffect(() => {
    fetchCustomer();
  }, [id]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setCustomerData((prev) => ({
      ...prev,
      [name]: value
    }));
  };

  const validateInputs = () => {
    const { cname, cphone, mailId, walletBal } = customerData;
    const phoneRegex = /^[6-9]\d{9}$/;
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    if (!cname.trim()) return 'Name is required.';
    if (!phoneRegex.test(cphone)) return 'Enter a valid 10-digit phone number.';
    if (mailId && !emailRegex.test(mailId)) return 'Invalid email format.';
    if (walletBal && isNaN(walletBal)) return 'Wallet balance must be a number.';
    return null;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const error = validateInputs();
    if (error) {
      setMessage({ type: 'error', text: error });
      return;
    }

    try {
      await axios.put(`http://localhost:5000/api/customers/updatecustomer/${id}`, customerData);
      setMessage({ type: 'success', text: 'Customer updated successfully!' });
      setTimeout(() => navigate('/'), 1500);
    } catch (err) {
      console.error('Update failed:', err);
      setMessage({ type: 'error', text: 'Update failed. Please try again.' });
    }
  };

  return (
    <div className="container mt-4">
      <div className="row justify-content-center">
        <div className="col-md-6">
          <div className="card shadow p-4">
            <h3 className="text-success mb-3">✏️ Update Customer</h3>
            <form onSubmit={handleSubmit}>
              <div className="mb-3">
                <label className="form-label">Customer ID</label>
                <input
                  type="text"
                  className="form-control"
                  value={customerData.customerId}
                  disabled
                />
              </div>

              <div className="mb-3">
                <label className="form-label">Name</label>
                <input
                  type="text"
                  className="form-control"
                  name="cname"
                  value={customerData.cname}
                  onChange={handleChange}
                  required
                />
              </div>

              <div className="mb-3">
                <label className="form-label">Phone</label>
                <input
                  type="text"
                  className="form-control"
                  name="cphone"
                  value={customerData.cphone}
                  onChange={handleChange}
                  required
                  maxLength="10"
                />
              </div>

              <div className="mb-3">
                <label className="form-label">Email</label>
                <input
                  type="email"
                  className="form-control"
                  name="mailId"
                  value={customerData.mailId}
                  onChange={handleChange}
                />
              </div>

              <div className="mb-3">
                <label className="form-label">Address</label>
                <textarea
                  className="form-control"
                  name="address"
                  value={customerData.address}
                  onChange={handleChange}
                />
              </div>

              <div className="mb-3">
                <label className="form-label">Customer Type</label>
                <select
                  className="form-select"
                  name="category"
                  value={customerData.category}
                  onChange={handleChange}
                >
                  <option value="Wholesaler">Wholesaler</option>
                  <option value="Retailer">Retailer</option>
                </select>
              </div>

              <div className="mb-3">
                <label className="form-label">Wallet Balance</label>
                <input
                  type="number"
                  className="form-control"
                  name="walletBal"
                  value={customerData.walletBal}
                  onChange={handleChange}
                />
              </div>

              <button type="submit" className="btn btn-success me-2">Update</button>
              <button type="button" className="btn btn-secondary" onClick={() => navigate('/')}>Cancel</button>
            </form>
            {message.text && (
              <div className={`alert mt-4 ${message.type === 'success' ? 'alert-success' : 'alert-danger'}`}>
                {message.text}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default UpdateCustomer;
