import { useState } from 'react';
import axios from 'axios';
import 'bootstrap/dist/css/bootstrap.min.css';
import { useNavigate } from 'react-router';

const AddProductForm = () => {
  const [formData, setFormData] = useState({
    pname: '',
    saleprice: '',
    MRP: '',
    stock: '',
    GST: '',
    batchNo: '',
    category: '',
  });

  const [errors, setErrors] = useState({});
  const [touched, setTouched] = useState({});
  const navigate = useNavigate();

  const categories = ['Groceries', 'Fashion', 'Beauty Products', 'Electronics', 'Pharmacy'];

  const handleChange = e => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    setTouched(prev => ({ ...prev, [name]: true }));
    validateField(name, value);
  };

  const validateField = (name, value) => {
    let message = '';
    if (!value.trim()) {
      message = `${name} is required`;
    } else {
      if (['saleprice', 'MRP', 'stock', 'GST'].includes(name)) {
        if (isNaN(value) || Number(value) < 0) {
          message = 'Enter a valid positive number';
        }
      }
    }
    setErrors(prev => ({ ...prev, [name]: message }));
  };

  const isFormValid = () => {
    return Object.values(formData).every(val => val.trim()) &&
           Object.values(errors).every(err => err === '');
  };

  const handleSubmit = async e => {
    e.preventDefault();
    const allFieldsValid = Object.keys(formData).every(key => {
      validateField(key, formData[key]);
      return !errors[key];
    });
    if (!allFieldsValid) return;

    try {
      const response = await axios.post('http://localhost:5000/api/products/add', formData);
      alert('✅ Product added with ID: ' + response.data.product.productId);
      navigate('/managerHome');
    } catch (error) {
      alert('❌ Error adding product');
      console.error(error);
    }
  };

  const renderInput = (label, name, type = "text") => (
    <div className="mb-3">
      <label htmlFor={name} className="form-label fw-semibold">{label}</label>
      <input
        type={type}
        className={`form-control ${touched[name] && errors[name] ? 'is-invalid' : ''}`}
        id={name}
        name={name}
        placeholder={`Enter ${label}`}
        value={formData[name]}
        onChange={handleChange}
        onBlur={() => {
          setTouched(prev => ({ ...prev, [name]: true }));
          validateField(name, formData[name]);
        }}
      />
      {touched[name] && errors[name] && (
        <div className="invalid-feedback">{errors[name]}</div>
      )}
    </div>
  );

  return (
    <div className="container mt-5">
      <div className="card shadow-lg p-4 bg-light" style={{ maxWidth: '650px', margin: '0 auto' }}>
        <h3 className="card-title mb-4 text-center text-primary">🛍️ Add New Product</h3>
        <form onSubmit={handleSubmit}>
          {renderInput("Product Name", "pname")}
          {renderInput("Sale Price (₹)", "saleprice", "number")}
          {renderInput("MRP (₹)", "MRP", "number")}
          {renderInput("Stock", "stock", "number")}
          {renderInput("GST (%)", "GST", "number")}
          {renderInput("Batch Number", "batchNo")}

          <div className="mb-4">
            <label htmlFor="category" className="form-label fw-semibold">Category</label>
            <select
              className={`form-select ${touched.category && errors.category ? 'is-invalid' : ''}`}
              id="category"
              name="category"
              value={formData.category}
              onChange={handleChange}
              onBlur={() => {
                setTouched(prev => ({ ...prev, category: true }));
                validateField('category', formData.category);
              }}
            >
              <option value="">Select Category</option>
              {categories.map(cat => (
                <option key={cat} value={cat}>{cat}</option>
              ))}
            </select>
            {touched.category && errors.category && (
              <div className="invalid-feedback">{errors.category}</div>
            )}
          </div>

          <div className="d-grid">
            <button
              type="submit"
              className="btn btn-primary fw-bold"
              disabled={!isFormValid()}
            >
              ➕ Add Product
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default AddProductForm;
