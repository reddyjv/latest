import React from 'react';
import Navbar from './Navbar';
import ManNavbar from './ManNavbar'


function ManDashboard({ user}) {
    return (
        
        <>
            <ManNavbar user={user}/>
            <div className="container mt-5">
                <h2>Welcome, {user.name}!</h2>
                <p>You have successfully logged in. Here’s your dashboard.</p>
            </div>
        </>
    );
}

export default ManDashboard;
